package com.roman.mychrysler300c;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import java.util.Calendar;

public class MainActivity extends Activity {
    private LinearLayout content;
    private CarDb db;
    private String tab = "Главная";

    private final int BG = Color.rgb(241,245,249);
    private final int DARK = Color.rgb(2,6,23);
    private final int CARD = Color.WHITE;
    private final int BLUE = Color.rgb(37,99,235);
    private final int GREEN = Color.rgb(22,163,74);
    private final int ORANGE = Color.rgb(234,88,12);
    private final int PURPLE = Color.rgb(124,58,237);
    private final int GRAY_TEXT = Color.rgb(71,85,105);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        db = new CarDb(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        scheduleReminder();
        buildLayout();
        render();
    }

    private void scheduleReminder() {
        Intent intent = new Intent(this, NotificationReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(this, 300, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 10); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0);
        if (cal.getTimeInMillis() < System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(24), dp(18), dp(18));
        header.setBackground(makeGradient(DARK, Color.rgb(15,23,42), 0));

        TextView title = new TextView(this);
        title.setText("Мой Chrysler 300C");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Native PRO 1.1 · журнал авто · ТО · топливо · запчасти");
        sub.setTextColor(Color.rgb(203,213,225));
        sub.setTextSize(13);
        sub.setPadding(0, dp(5), 0, 0);
        header.addView(sub);
        root.addView(header);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));

        String[] tabs = {"Главная","ТО","Топливо","Запчасти","Жидкости","Ошибки","Аналоги","Резерв"};
        for (String t: tabs) {
            TextView btn = new TextView(this);
            btn.setText(t);
            btn.setGravity(Gravity.CENTER);
            btn.setTextSize(14);
            btn.setTypeface(null, Typeface.BOLD);
            btn.setTextColor(t.equals(tab) ? Color.WHITE : DARK);
            btn.setBackground(rounded(t.equals(tab) ? BLUE : Color.WHITE, dp(22)));
            btn.setOnClickListener(v -> { tab = ((TextView)v).getText().toString(); buildLayout(); render(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(112), dp(44));
            lp.setMargins(dp(4), 0, dp(4), 0);
            nav.addView(btn, lp);
        }
        hsv.addView(nav);
        root.addView(hsv);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(4), dp(12), dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void render() {
        content.removeAllViews();
        if (tab.equals("Главная")) renderHome();
        else if (tab.equals("ТО")) renderMaintenance();
        else if (tab.equals("Топливо")) renderFuel();
        else if (tab.equals("Запчасти")) renderParts();
        else if (tab.equals("Жидкости")) renderFluids();
        else if (tab.equals("Ошибки")) renderErrors();
        else if (tab.equals("Аналоги")) renderAlternatives();
        else renderBackup();
    }

    private void renderHome() {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM car_profile WHERE id=1", null);
        if (c.moveToFirst()) {
            heroCard("CHRYSLER 300C", "2005 · 2.7 V6 · С800ТУ 22",
                    "VIN: " + val(c,"vin") + "\nПробег: " + c.getInt(c.getColumnIndexOrThrow("mileage")) + " км\n" + val(c,"note"));
        }
        c.close();

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.HORIZONTAL);
        content.addView(grid);
        miniCard(grid, "ТО", "ГРМ заменён\n217293 км", GREEN);
        miniCard(grid, "Масло", "ZIC 5W-40\n217200 км", ORANGE);

        addButton("🔔 Проверить уведомление", BLUE, () ->
                NotificationReceiver.show(this, "Контроль Chrysler 300C", "Тест уведомления работает."));

        card("Ближайшие задачи", "• Следующая замена масла: ориентир 227200 км\n• Тройник охлаждения: Mopar 04596509AB\n• Жидкость ГУР потемнела — рекомендована замена\n• Рейка/насос ГУР — контроль состояния", PURPLE);
        card("Что уже есть", "SQLite-база, ТО, бензин/газ, запчасти, жидкости, ошибки OBD2, аналоги, JSON-экспорт на экран, уведомление-тест.", BLUE);
    }

    private void renderMaintenance() {
        section("Журнал технического обслуживания");
        addButton("➕ Добавить ТО", GREEN, this::showMaintenanceForm);
        Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM maintenance ORDER BY id DESC", null);
        while (c.moveToNext()) card(val(c,"title"),
                "Дата: "+val(c,"date")+"\nПробег: "+c.getInt(c.getColumnIndexOrThrow("mileage"))+" км\nКатегория: "+val(c,"category")+"\nСтоимость: "+c.getDouble(c.getColumnIndexOrThrow("cost"))+" ₽\n"+val(c,"note"), GREEN);
        c.close();
    }

    private void renderFuel() {
        section("Заправки и расход");
        addButton("⛽ Добавить бензин", ORANGE, () -> showFuelForm("Бензин"));
        addButton("🔥 Добавить газ", PURPLE, () -> showFuelForm("Газ"));
        Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM fuel ORDER BY id DESC", null);
        while (c.moveToNext()) {
            double liters = c.getDouble(c.getColumnIndexOrThrow("liters"));
            double cost = c.getDouble(c.getColumnIndexOrThrow("cost"));
            int km = c.getInt(c.getColumnIndexOrThrow("kmDriven"));
            String price = liters > 0 ? String.format("%.2f ₽/л", cost/liters) : "нет данных";
            String consumption = (liters > 0 && km > 0) ? String.format("%.2f л/100 км", liters * 100 / km) : "нет данных";
            card(val(c,"type"), "Дата: "+val(c,"date")+"\nПробег: "+c.getInt(c.getColumnIndexOrThrow("mileage"))+" км\nПроехал: "+km+" км\nЛитры: "+liters+"\nСтоимость: "+cost+" ₽\nЦена: "+price+"\nРасход: "+consumption+"\n"+val(c,"note"), ORANGE);
        }
        c.close();
    }

    private void renderParts() {
        section("Запчасти и покупки");
        addButton("➕ Добавить запчасть", BLUE, this::showPartForm);
        Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM parts ORDER BY id DESC", null);
        while (c.moveToNext()) card(val(c,"name"), "Статус: "+val(c,"status")+"\nИсточник: "+val(c,"source")+"\nСтоимость: "+c.getDouble(c.getColumnIndexOrThrow("cost"))+" ₽\n"+val(c,"note"), BLUE);
        c.close();
    }

    private void renderFluids() {
        section("Жидкости Chrysler 300C");
        card("Двигатель", "Моторное масло: 5W-30 по мануалу / 5W-40 ZIC X9 по текущему использованию\nОбъём: примерно 5.0–5.5 л с фильтром\nФильтр: MANN W712/80", ORANGE);
        card("АКПП", "ATF+4. Частичная замена около 4–5 л. Проверка уровня по температуре.", PURPLE);
        card("ГУР", "PSF Chrysler/Mopar. До уровня в бачке. У тебя жидкость потемнела — рекомендована замена.", BLUE);
        card("Охлаждение", "Антифриз HOAT/G-05. Полный объём около 9–10 л. Проверить тройник 04596509AB.", GREEN);
        card("Редуктор", "75W-90 GL-5. Заливать до нижней кромки заливного отверстия.", DARK);
    }

    private void renderErrors() {
        section("Ошибки OBD-II");
        card("P0300", "Случайные пропуски зажигания: свечи, катушки, форсунки, подсос, компрессия.", ORANGE);
        card("P0420 / P0430", "Катализатор. Сначала проверить пропуски, смесь, лямбда-зонды, выхлоп.", PURPLE);
        card("P0700", "Запрос MIL от АКПП. Нужно читать отдельные коды блока TCM.", BLUE);
        card("P0128", "Температура ОЖ ниже нормы. Часто термостат.", GREEN);
    }

    private void renderAlternatives() {
        section("Аналоги масел и жидкостей");
        card("Моторное масло", "ZIC X9 5W-40, Mobil 1 FS 5W-40, Shell Helix Ultra 5W-40, Liqui Moly 5W-40, Lukoil Genesis 5W-40.\nAPI SN/SM и выше, ACEA A3/B4.", ORANGE);
        card("АКПП", "Mopar ATF+4, Ravenol ATF+4, Febi ATF+4, Valvoline ATF+4. Dexron не лить.", PURPLE);
        card("Антифриз", "Mopar HOAT/G-05, Zerex G-05, Coolstream Premium, Febi G05.", GREEN);
        card("Редуктор", "75W-90 GL-5: Motul Gear 300, Liqui Moly, Castrol Syntrax.", BLUE);
    }

    private void renderBackup() {
        section("Резервная копия");
        addButton("📦 Показать JSON резервной копии", DARK, () -> {
            try { card("JSON", db.exportJson().toString(2), DARK); } catch(Exception e) { toast("Ошибка: "+e.getMessage()); }
        });
        card("Следующий этап", "Добавим сохранение JSON в файл, импорт из файла и позже синхронизацию с Google Drive.", BLUE);
    }

    private void showMaintenanceForm() {
        LinearLayout box = form("Новое ТО");
        EditText date=input("Дата дд.мм.гггг"), mileage=num("Пробег"), title=input("Что сделано"), cat=input("Категория"), cost=dec("Стоимость"), note=input("Заметка");
        box.addView(date); box.addView(mileage); box.addView(title); box.addView(cat); box.addView(cost); box.addView(note);
        Button save=button("Сохранить ТО", GREEN);
        save.setOnClickListener(v->{ db.insertMaintenance(db.getWritableDatabase(), date.getText().toString(), toInt(mileage), title.getText().toString(), cat.getText().toString(), note.getText().toString(), toDouble(cost)); renderMaintenance(); });
        box.addView(save); content.addView(box);
    }

    private void showFuelForm(String type) {
        LinearLayout box = form("Заправка: "+type);
        EditText date=input("Дата"), mileage=num("Пробег"), km=num("Проехал км"), liters=dec("Литры"), cost=dec("Стоимость"), note=input("Заметка");
        box.addView(date); box.addView(mileage); box.addView(km); box.addView(liters); box.addView(cost); box.addView(note);
        Button save=button("Сохранить", ORANGE);
        save.setOnClickListener(v->{ db.insertFuel(date.getText().toString(), type, toInt(mileage), toInt(km), toDouble(liters), toDouble(cost), note.getText().toString()); renderFuel(); });
        box.addView(save); content.addView(box);
    }

    private void showPartForm() {
        LinearLayout box = form("Новая запчасть");
        EditText name=input("Название"), status=input("Статус"), source=input("Где купить"), cost=dec("Стоимость"), note=input("Заметка");
        box.addView(name); box.addView(status); box.addView(source); box.addView(cost); box.addView(note);
        Button save=button("Сохранить", BLUE);
        save.setOnClickListener(v->{ db.insertPart(db.getWritableDatabase(), name.getText().toString(), status.getText().toString(), source.getText().toString(), note.getText().toString(), toDouble(cost)); renderParts(); });
        box.addView(save); content.addView(box);
    }

    private LinearLayout form(String title){
        LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(dp(18),dp(18),dp(18),dp(18)); b.setBackground(rounded(CARD, dp(18)));
        TextView t=new TextView(this); t.setText(title); t.setTextSize(20); t.setTypeface(null,Typeface.BOLD); t.setTextColor(DARK); b.addView(t);
        return b;
    }

    private void heroCard(String title, String subtitle, String body) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(20), dp(20), dp(20));
        box.setBackground(makeGradient(Color.rgb(15,23,42), Color.rgb(30,64,175), dp(22)));

        TextView car = new TextView(this);
        car.setText("▰▰▰  300C  ▰▰▰");
        car.setTextSize(26);
        car.setGravity(Gravity.CENTER);
        car.setTextColor(Color.WHITE);
        car.setTypeface(null, Typeface.BOLD);
        box.addView(car);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(24);
        t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(12), 0, 0);
        box.addView(t);

        TextView s = new TextView(this);
        s.setText(subtitle);
        s.setTextColor(Color.rgb(191,219,254));
        s.setTextSize(15);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, dp(4), 0, dp(12));
        box.addView(s);

        TextView b = new TextView(this);
        b.setText(body);
        b.setTextColor(Color.rgb(226,232,240));
        b.setTextSize(15);
        b.setLineSpacing(2, 1.05f);
        box.addView(b);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(14));
        content.addView(box, lp);
    }

    private void miniCard(LinearLayout parent, String title, String body, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(rounded(CARD, dp(18)));

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(color);
        t.setTextSize(17);
        t.setTypeface(null, Typeface.BOLD);
        box.addView(t);

        TextView b = new TextView(this);
        b.setText(body);
        b.setTextColor(DARK);
        b.setTextSize(14);
        b.setPadding(0, dp(6), 0, 0);
        box.addView(b);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(4), 0, dp(4), dp(14));
        parent.addView(box, lp);
    }

    private void section(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(DARK);
        v.setTextSize(22);
        v.setTypeface(null, Typeface.BOLD);
        v.setPadding(dp(4), dp(10), dp(4), dp(12));
        content.addView(v);
    }

    private void card(String title,String body,int accent){
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setBackground(rounded(CARD, dp(18)));

        TextView stripe = new TextView(this);
        stripe.setBackgroundColor(accent);
        box.addView(stripe, new LinearLayout.LayoutParams(dp(7), -1));

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(16), dp(14), dp(16), dp(14));

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(18);
        t.setTextColor(DARK);
        t.setTypeface(null, Typeface.BOLD);
        inner.addView(t);

        TextView b = new TextView(this);
        b.setText(body);
        b.setTextSize(15);
        b.setTextColor(GRAY_TEXT);
        b.setPadding(0, dp(6), 0, 0);
        b.setLineSpacing(2, 1.05f);
        inner.addView(b);

        box.addView(inner, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,0,0,dp(12));
        content.addView(box,lp);
    }

    private void addButton(String text, int color, Runnable action){
        Button b=button(text, color);
        b.setOnClickListener(v->action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(0, 0, 0, dp(12));
        content.addView(b, lp);
    }

    private Button button(String text, int color){
        Button b=new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(rounded(color, dp(18)));
        return b;
    }

    private GradientDrawable rounded(int color, int radius){ GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    private GradientDrawable makeGradient(int a, int b, int radius){ GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a,b}); g.setCornerRadius(radius); return g; }
    private EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(15); e.setSingleLine(false); return e; }
    private EditText num(String hint){ EditText e=input(hint); e.setInputType(InputType.TYPE_CLASS_NUMBER); return e; }
    private EditText dec(String hint){ EditText e=input(hint); e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); return e; }
    private int toInt(EditText e){ try{return Integer.parseInt(e.getText().toString());}catch(Exception ex){return 0;} }
    private double toDouble(EditText e){ try{return Double.parseDouble(e.getText().toString());}catch(Exception ex){return 0;} }
    private String val(Cursor c,String col){ return c.getString(c.getColumnIndexOrThrow(col)); }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}