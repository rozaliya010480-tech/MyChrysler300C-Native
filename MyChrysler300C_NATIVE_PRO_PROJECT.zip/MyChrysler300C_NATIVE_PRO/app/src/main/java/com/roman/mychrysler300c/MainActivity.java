package com.roman.mychrysler300c;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.widget.*;
import java.util.Calendar;

public class MainActivity extends Activity {
    private LinearLayout content;
    private CarDb db;
    private String tab = "Главная";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        db = new CarDb(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        scheduleReminder();
        buildLayout();
        render();
    }

    private void scheduleReminder() {
        Intent intent = new Intent(this, NotificationReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(this, 300, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 10); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0);
        if (cal.getTimeInMillis() < System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF1F5F9);

        TextView header = new TextView(this);
        header.setText("Мой Chrysler 300C\nNative PRO · SQLite · уведомления");
        header.setTextColor(0xFFFFFFFF);
        header.setTextSize(20);
        header.setTypeface(null, Typeface.BOLD);
        header.setPadding(24,34,24,24);
        header.setBackgroundColor(0xFF020617);
        root.addView(header);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        LinearLayout nav = new LinearLayout(this);
        String[] tabs = {"Главная","ТО","Топливо","Запчасти","Жидкости","Ошибки","Аналоги","Резерв"};
        for (String t: tabs) {
            Button btn = new Button(this);
            btn.setText(t); btn.setAllCaps(false);
            btn.setOnClickListener(v -> { tab = ((Button)v).getText().toString(); render(); });
            nav.addView(btn, new LinearLayout.LayoutParams(dp(112), dp(48)));
        }
        hsv.addView(nav); root.addView(hsv);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(14,10,14,24);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void render() {
        content.removeAllViews();
        if (tab.equals("Главная")) renderHome();
        else if (tab.equals("ТО")) renderMaintenance();
        else if (tab.equals("Топливо")) renderFuel();
        else if (tab.equals("Запчасти")) renderParts();
        else if (tab.equals("Жидкости")) renderFluids();
        else if (tab.equals("Ошибки")) renderErrors();
        else if (tab.equals("Аналоги")) renderAlternatives();
        else renderBackup();
    }

    private void renderHome() {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM car_profile WHERE id=1", null);
        if (c.moveToFirst()) {
            card("Автомобиль", "Chrysler 300C, 2005\nГосномер: " + val(c,"plate") + "\nVIN: " + val(c,"vin") + "\nДвигатель: " + val(c,"engine") + "\nПробег: " + c.getInt(c.getColumnIndexOrThrow("mileage")) + " км");
        }
        c.close();
        addButton("Проверить уведомление", () -> NotificationReceiver.show(this, "Контроль Chrysler 300C", "Тест уведомления работает."));
        card("План развития", "Это нативная основа. Дальше добавим редактирование профиля, удаление записей, фото чеков, графики, полноценный импорт/экспорт.");
    }

    private void renderMaintenance() {
        addButton("+ Добавить ТО", this::showMaintenanceForm);
        Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM maintenance ORDER BY id DESC", null);
        while (c.moveToNext()) card(val(c,"title"), "Дата: "+val(c,"date")+"\nПробег: "+c.getInt(c.getColumnIndexOrThrow("mileage"))+"\nКатегория: "+val(c,"category")+"\nСтоимость: "+c.getDouble(c.getColumnIndexOrThrow("cost"))+" ₽\n"+val(c,"note"));
        c.close();
    }

    private void renderFuel() {
        addButton("+ Бензин", () -> showFuelForm("Бензин"));
        addButton("+ Газ", () -> showFuelForm("Газ"));
        Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM fuel ORDER BY id DESC", null);
        while (c.moveToNext()) {
            double liters = c.getDouble(c.getColumnIndexOrThrow("liters"));
            double cost = c.getDouble(c.getColumnIndexOrThrow("cost"));
            String price = liters > 0 ? String.format("%.2f ₽/л", cost/liters) : "нет данных";
            card(val(c,"type"), "Дата: "+val(c,"date")+"\nПробег: "+c.getInt(c.getColumnIndexOrThrow("mileage"))+"\nПроехал: "+c.getInt(c.getColumnIndexOrThrow("kmDriven"))+" км\nЛитры: "+liters+"\nСтоимость: "+cost+" ₽\nЦена: "+price+"\n"+val(c,"note"));
        }
        c.close();
    }

    private void renderParts() {
        addButton("+ Добавить запчасть", this::showPartForm);
        Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM parts ORDER BY id DESC", null);
        while (c.moveToNext()) card(val(c,"name"), "Статус: "+val(c,"status")+"\nИсточник: "+val(c,"source")+"\nСтоимость: "+c.getDouble(c.getColumnIndexOrThrow("cost"))+" ₽\n"+val(c,"note"));
        c.close();
    }

    private void renderFluids() {
        card("Двигатель", "Моторное масло: 5W-30 по мануалу / 5W-40 ZIC X9 по текущему использованию\nОбъём: примерно 5.0–5.5 л с фильтром\nФильтр: MANN W712/80");
        card("АКПП", "ATF+4. Частичная замена около 4–5 л. Проверка уровня по температуре.");
        card("ГУР", "PSF Chrysler/Mopar. До уровня в бачке. У тебя жидкость потемнела — рекомендована замена.");
        card("Охлаждение", "Антифриз HOAT/G-05. Полный объём около 9–10 л. Проверить тройник 04596509AB.");
        card("Задний мост / редуктор", "75W-90 GL-5. Заливать до нижней кромки заливного отверстия.");
    }

    private void renderErrors() {
        card("P0300", "Случайные пропуски зажигания: свечи, катушки, форсунки, подсос, компрессия.");
        card("P0420 / P0430", "Катализатор. Сначала проверить пропуски, смесь, лямбда-зонды, выхлоп.");
        card("P0700", "Запрос MIL от АКПП. Нужно читать отдельные коды блока TCM.");
        card("P0128", "Температура ОЖ ниже нормы. Часто термостат.");
    }

    private void renderAlternatives() {
        card("Моторное масло", "ZIC X9 5W-40, Mobil 1 FS 5W-40, Shell Helix Ultra 5W-40, Liqui Moly 5W-40, Lukoil Genesis 5W-40.\nAPI SN/SM и выше, ACEA A3/B4.");
        card("АКПП", "Mopar ATF+4, Ravenol ATF+4, Febi ATF+4, Valvoline ATF+4. Dexron не лить.");
        card("Антифриз", "Mopar HOAT/G-05, Zerex G-05, Coolstream Premium, Febi G05.");
        card("Редуктор", "75W-90 GL-5: Motul Gear 300, Liqui Moly, Castrol Syntrax.");
    }

    private void renderBackup() {
        addButton("Показать JSON резервной копии", () -> {
            try { card("JSON", db.exportJson().toString(2)); } catch(Exception e) { toast("Ошибка: "+e.getMessage()); }
        });
        card("Следующий этап", "Добавим сохранение JSON в файл и импорт из файла через системный выбор.");
    }

    private void showMaintenanceForm() {
        LinearLayout box = form("Новое ТО"); EditText date=input("Дата дд.мм.гггг"), mileage=num("Пробег"), title=input("Что сделано"), cat=input("Категория"), cost=dec("Стоимость"), note=input("Заметка");
        box.addView(date); box.addView(mileage); box.addView(title); box.addView(cat); box.addView(cost); box.addView(note);
        Button save=button("Сохранить ТО"); save.setOnClickListener(v->{ db.insertMaintenance(db.getWritableDatabase(), date.getText().toString(), toInt(mileage), title.getText().toString(), cat.getText().toString(), note.getText().toString(), toDouble(cost)); renderMaintenance(); }); box.addView(save); content.addView(box);
    }

    private void showFuelForm(String type) {
        LinearLayout box = form("Заправка: "+type); EditText date=input("Дата"), mileage=num("Пробег"), km=num("Проехал км"), liters=dec("Литры"), cost=dec("Стоимость"), note=input("Заметка");
        box.addView(date); box.addView(mileage); box.addView(km); box.addView(liters); box.addView(cost); box.addView(note);
        Button save=button("Сохранить"); save.setOnClickListener(v->{ db.insertFuel(date.getText().toString(), type, toInt(mileage), toInt(km), toDouble(liters), toDouble(cost), note.getText().toString()); renderFuel(); }); box.addView(save); content.addView(box);
    }

    private void showPartForm() {
        LinearLayout box = form("Новая запчасть"); EditText name=input("Название"), status=input("Статус"), source=input("Где купить"), cost=dec("Стоимость"), note=input("Заметка");
        box.addView(name); box.addView(status); box.addView(source); box.addView(cost); box.addView(note);
        Button save=button("Сохранить"); save.setOnClickListener(v->{ db.insertPart(db.getWritableDatabase(), name.getText().toString(), status.getText().toString(), source.getText().toString(), note.getText().toString(), toDouble(cost)); renderParts(); }); box.addView(save); content.addView(box);
    }

    private LinearLayout form(String title){ LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(20,20,20,20); b.setBackgroundColor(0xFFFFFFFF); TextView t=new TextView(this); t.setText(title); t.setTextSize(20); t.setTypeface(null,Typeface.BOLD); b.addView(t); return b; }
    private EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); return e; }
    private EditText num(String hint){ EditText e=input(hint); e.setInputType(InputType.TYPE_CLASS_NUMBER); return e; }
    private EditText dec(String hint){ EditText e=input(hint); e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); return e; }
    private Button button(String text){ Button b=new Button(this); b.setText(text); b.setAllCaps(false); return b; }
    private int toInt(EditText e){ try{return Integer.parseInt(e.getText().toString());}catch(Exception ex){return 0;} }
    private double toDouble(EditText e){ try{return Double.parseDouble(e.getText().toString());}catch(Exception ex){return 0;} }
    private String val(Cursor c,String col){ return c.getString(c.getColumnIndexOrThrow(col)); }
    private void card(String title,String body){ TextView v=new TextView(this); v.setText(title+"\n"+body); v.setTextSize(16); v.setPadding(22,18,22,18); v.setBackgroundColor(0xFFFFFFFF); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,14); content.addView(v,lp); }
    private void addButton(String text, Runnable action){ Button b=button(text); b.setOnClickListener(v->action.run()); content.addView(b,new LinearLayout.LayoutParams(-1,dp(52))); }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}