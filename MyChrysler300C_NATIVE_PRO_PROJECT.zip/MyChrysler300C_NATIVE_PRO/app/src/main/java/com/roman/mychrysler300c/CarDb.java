package com.roman.mychrysler300c;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;

public class CarDb extends SQLiteOpenHelper {
    public CarDb(Context context) { super(context, "chrysler300c.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE car_profile (id INTEGER PRIMARY KEY, brand TEXT, model TEXT, year TEXT, plate TEXT, vin TEXT, engine TEXT, mileage INTEGER, note TEXT)");
        db.execSQL("CREATE TABLE maintenance (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, mileage INTEGER, title TEXT, category TEXT, note TEXT, cost REAL)");
        db.execSQL("CREATE TABLE fuel (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, type TEXT, mileage INTEGER, kmDriven INTEGER, liters REAL, cost REAL, note TEXT)");
        db.execSQL("CREATE TABLE parts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, status TEXT, source TEXT, note TEXT, cost REAL)");
        seed(db);
    }

    private void seed(SQLiteDatabase db) {
        ContentValues car = new ContentValues();
        car.put("id", 1); car.put("brand", "Chrysler"); car.put("model", "300C"); car.put("year", "2005");
        car.put("plate", "С800ТУ 22"); car.put("vin", "1C3H8B3R56Y115967"); car.put("engine", "2.7 V6");
        car.put("mileage", 217293); car.put("note", "Задний привод, бензин + ГБО, Webasto.");
        db.insert("car_profile", null, car);
        insertMaintenance(db, "08.04.2026", 217293, "Полная замена ГРМ", "Двигатель", "Контролировать следующую замену по регламенту.", 0);
        insertMaintenance(db, "04.04.2026", 217200, "Замена масла", "ТО", "ZIC 5W-40, доливка Лукойл 5W-40, Liqui Moly Hydro-Stossel-Additiv.", 0);
        insertPart(db, "Масляный фильтр MANN W712/80", "подходит", "Rossko, Новосибирск, ул. Троллейная, 37", "Альтернатива: AZUMI.", 0);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public void insertMaintenance(SQLiteDatabase db, String date, int mileage, String title, String category, String note, double cost) {
        ContentValues v = new ContentValues();
        v.put("date", date); v.put("mileage", mileage); v.put("title", title); v.put("category", category); v.put("note", note); v.put("cost", cost);
        db.insert("maintenance", null, v);
    }

    public void insertFuel(String date, String type, int mileage, int kmDriven, double liters, double cost, String note) {
        ContentValues v = new ContentValues();
        v.put("date", date); v.put("type", type); v.put("mileage", mileage); v.put("kmDriven", kmDriven); v.put("liters", liters); v.put("cost", cost); v.put("note", note);
        getWritableDatabase().insert("fuel", null, v);
    }

    public void insertPart(SQLiteDatabase db, String name, String status, String source, String note, double cost) {
        ContentValues v = new ContentValues();
        v.put("name", name); v.put("status", status); v.put("source", source); v.put("note", note); v.put("cost", cost);
        db.insert("parts", null, v);
    }

    public JSONObject exportJson() throws Exception {
        SQLiteDatabase db = getReadableDatabase();
        JSONObject root = new JSONObject();
        root.put("car_profile", tableToJson(db, "car_profile"));
        root.put("maintenance", tableToJson(db, "maintenance"));
        root.put("fuel", tableToJson(db, "fuel"));
        root.put("parts", tableToJson(db, "parts"));
        return root;
    }

    private JSONArray tableToJson(SQLiteDatabase db, String table) throws Exception {
        JSONArray arr = new JSONArray();
        Cursor c = db.rawQuery("SELECT * FROM " + table, null);
        while (c.moveToNext()) {
            JSONObject o = new JSONObject();
            for (int i=0; i<c.getColumnCount(); i++) o.put(c.getColumnName(i), c.getString(i));
            arr.put(o);
        }
        c.close();
        return arr;
    }
}